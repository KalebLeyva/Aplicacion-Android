package com.unidad2tap.blocklock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ButtonDefaults
import kotlin.math.roundToInt

import com.unidad2tap.blocklock.ui.theme.BlockLockTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BlockLockTheme {
                LoginScreen()
            }
        }
    }
}

@Composable
fun LoginScreen() {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var emailError by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf(false) }
    var loginSuccess by remember { mutableStateOf(false) }

    val validDomains = listOf("gmail.com", "outlook.com", "itoaxaca.com", "hotmail.com")
    val correctPassword = "tap*2025"

    if (loginSuccess) {
        AppNavigator()
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Inicio de Sesión",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Correo electrónico") },
                isError = emailError,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
            )

            if (emailError) {
                Text(
                    text = "Correo inválido. Use @gmail.com, @outlook.com, @itoaxaca.com o @hotmail.com",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 16.dp, top = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Contraseña") },
                isError = passwordError,
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )

            if (passwordError) {
                Text(
                    text = "Contraseña incorrecta. Debe ser tap*2025",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 16.dp, top = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    // Validar email
                    val emailValid = email.isNotEmpty() &&
                            email.contains("@") &&
                            validDomains.any { domain ->
                                email.endsWith("@$domain")
                            }

                    // Validar contraseña
                    val passwordValid = password == correctPassword

                    emailError = !emailValid
                    passwordError = !passwordValid

                    if (emailValid && passwordValid) {
                        loginSuccess = true
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Iniciar Sesión")
            }
        }
    }
}

@Composable
fun AppNavigator() {
    var currentScreen by remember { mutableStateOf(-1) } // -1 es la pantalla principal

    when (currentScreen) {
        -1 -> MainMenu(onEjercicioSelected = { currentScreen = it })
        0 -> Ejercicio1(onBack = { currentScreen = -1 })
        1 -> Ejercicio2(onBack = { currentScreen = -1 })
        2 -> Ejercicio3(onBack = { currentScreen = -1 })
        3 -> Ejercicio4(onBack = { currentScreen = -1 })
        4 -> Ejercicio5(onBack = { currentScreen = -1 })
        5 -> Ejercicio6(onBack = { currentScreen = -1 })
        6 -> Ejercicio7(onBack = { currentScreen = -1 })
        7 -> Ejercicio8(onBack = { currentScreen = -1 })
        8 -> Ejercicio9(onBack = { currentScreen = -1 })
        9 -> Ejercicio10(onBack = { currentScreen = -1 })
        else -> Text("Ejercicio no disponible")
    }
}

@Composable
fun MainMenu(onEjercicioSelected: (Int) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Menú", style = MaterialTheme.typography.titleLarge)

        Button(
            onClick = { onEjercicioSelected(0) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF36C492),
                contentColor = Color.Black
            )
        ) {
            Text("Ejercicio 1")
        }

        Button(
            onClick = { onEjercicioSelected(1) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF36C492),
                contentColor = Color.Black
            )
        ) {
            Text("Ejercicio 2")
        }

        Button(
            onClick = { onEjercicioSelected(2) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF36C492),
                contentColor = Color.Black
            )
        ) {
            Text("Ejercicio 3")
        }

        Button(
            onClick = { onEjercicioSelected(3) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF36C492),
                contentColor = Color.Black
            )
        ) {
            Text("Ejercicio 4")
        }

        Button(
            onClick = { onEjercicioSelected(4) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF36C492),
                contentColor = Color.Black
            )
        ) {
            Text("Ejercicio 5")
        }

        Button(
            onClick = { onEjercicioSelected(5) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF36C492),
                contentColor = Color.Black
            )
        ) {
            Text("Ejercicio 6")
        }

        Button(
            onClick = { onEjercicioSelected(6) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF36C492),
                contentColor = Color.Black
            )
        ) {
            Text("Ejercicio 7")
        }

        Button(
            onClick = { onEjercicioSelected(7) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF36C492),
                contentColor = Color.Black
            )
        ) {
            Text("Ejercicio 8")
        }

        Button(
            onClick = { onEjercicioSelected(8) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF36C492),
                contentColor = Color.Black
            )
        ) {
            Text("Ejercicio 9")
        }

        Button(
            onClick = { onEjercicioSelected(9) },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF36C492),
                contentColor = Color.Black
            )
        ) {
            Text("Ejercicio 10")
        }
    }
}

@Composable
fun Ejercicio1(onBack: () -> Unit) {
    var perro by remember { mutableStateOf(false) }
    var gato by remember { mutableStateOf(false) }
    var raton by remember { mutableStateOf(false) }
    var mensaje by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Ejercicio 1", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))

        Row { Checkbox(checked = perro, onCheckedChange = { perro = it }); Text("Perro", modifier = Modifier.padding(start = 8.dp)) }
        Row { Checkbox(checked = gato, onCheckedChange = { gato = it }); Text("Gato", modifier = Modifier.padding(start = 8.dp)) }
        Row { Checkbox(checked = raton, onCheckedChange = { raton = it }); Text("Ratón", modifier = Modifier.padding(start = 8.dp)) }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            val seleccionados = mutableListOf<String>()
            if (perro) seleccionados.add("Perro")
            if (gato) seleccionados.add("Gato")
            if (raton) seleccionados.add("Ratón")
            mensaje = if (seleccionados.isEmpty()) "No has escogido nada" else "Has escogido: ${seleccionados.joinToString(", ")}"
        }) {
            Text("Aceptar")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = mensaje)

        Spacer(modifier = Modifier.height(32.dp))

        Button(onClick = onBack) {
            Text("Volver al menú")
        }
    }
}

@Composable
fun Ejercicio2(onBack: () -> Unit) {
    var colorSeleccionado by remember { mutableStateOf("") }
    var mensaje by remember { mutableStateOf("") }

    val colores = listOf("Rojo", "Azul", "Verde")

    Column {
        Text(text = "Ejercicio 2", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))

        colores.forEach { color ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = (colorSeleccionado == color),
                    onClick = { colorSeleccionado = color }
                )
                Text(text = color, modifier = Modifier.padding(start = 8.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            mensaje = if (colorSeleccionado.isNotEmpty()) {
                "Color elegido: $colorSeleccionado"
            } else {
                "No has elegido ningún color"
            }
        }) {
            Text("Aceptar")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = mensaje)

        Button(onClick = onBack) {
            Text("Volver al menú")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio3(onBack: () -> Unit) {
    val colores = listOf("Rojo", "Verde", "Azul")
    var colorSeleccionado by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    Column {
        Text(text = "Ejercicio 3", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))

        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            TextField(
                value = colorSeleccionado,
                onValueChange = {},
                readOnly = true,
                label = { Text("Selecciona un color") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                modifier = Modifier.menuAnchor()
            )

            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                colores.forEach { color ->
                    DropdownMenuItem(
                        text = { Text(text = color) },
                        onClick = {
                            colorSeleccionado = color
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (colorSeleccionado.isNotEmpty()) {
            Text(text = "El color elegido es $colorSeleccionado")
        }

        Button(onClick = onBack) {
            Text("Volver al menú")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Ejercicio4(onBack: () -> Unit) {
    val impares = listOf(1, 3, 5, 7, 9).map { it.toString() }
    val pares = listOf(2, 4, 6, 8, 10).map { it.toString() }

    var seleccionTipo by remember { mutableStateOf<String?>(null) }
    var opciones by remember { mutableStateOf(listOf<String>()) }
    var numeroSeleccionado by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Ejercicio 4", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(16.dp))

        Row {
            Button(
                onClick = {
                    seleccionTipo = "Impar"
                    opciones = impares
                    numeroSeleccionado = ""
                    expanded = false
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Impar")
            }

            Spacer(modifier = Modifier.width(16.dp))

            Button(
                onClick = {
                    seleccionTipo = "Par"
                    opciones = pares
                    numeroSeleccionado = ""
                    expanded = false
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Par")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            TextField(
                value = numeroSeleccionado,
                onValueChange = {},
                readOnly = true,
                label = { Text("Selecciona un número") },
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                },
                enabled = opciones.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor()
                    .clickable(enabled = opciones.isNotEmpty()) { expanded = !expanded }
            )

            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                opciones.forEach { numero ->
                    DropdownMenuItem(
                        text = { Text(text = numero) },
                        onClick = {
                            numeroSeleccionado = numero
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (numeroSeleccionado.isNotEmpty())
                "Número seleccionado: $numeroSeleccionado"
            else "",
            style = MaterialTheme.typography.bodyLarge
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                seleccionTipo = null
                opciones = emptyList()
                numeroSeleccionado = ""
                expanded = false
            }
        ) {
            Text("Limpiar")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = onBack) {
            Text("Volver al menú")
        }
    }
}
@Composable
fun Ejercicio5(onBack: () -> Unit) {
    var precioBaseTexto by remember { mutableStateOf("") }
    var incluirInstalacion by remember { mutableStateOf(false) }
    var incluirFormacion by remember { mutableStateOf(false) }
    var incluirAlimentacionBD by remember { mutableStateOf(false) }
    var total by remember { mutableStateOf(0.0) }

    val precioInstalacion = 40.0
    val precioFormacion = 200.0
    val precioAlimentacionBD = 200.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "Ejercicio 5", style = MaterialTheme.typography.titleLarge)

        Text(text = "Precio Base", style = MaterialTheme.typography.titleMedium)
        TextField(
            value = precioBaseTexto,
            onValueChange = { precioBaseTexto = it },
            label = { Text("Ingrese el precio base") },
            singleLine = true
        )

        ToggleButton(
            texto = "Instalación",
            activo = incluirInstalacion,
            onClick = { incluirInstalacion = !incluirInstalacion }
        )

        ToggleButton(
            texto = "Formación",
            activo = incluirFormacion,
            onClick = { incluirFormacion = !incluirFormacion }
        )

        ToggleButton(
            texto = "Alimentación BD",
            activo = incluirAlimentacionBD,
            onClick = { incluirAlimentacionBD = !incluirAlimentacionBD }
        )

        Button(onClick = {
            val base = precioBaseTexto.toDoubleOrNull() ?: 0.0
            total = base +
                    (if (incluirInstalacion) precioInstalacion else 0.0) +
                    (if (incluirFormacion) precioFormacion else 0.0) +
                    (if (incluirAlimentacionBD) precioAlimentacionBD else 0.0)
        }) {
            Text("Calcular")
        }

        Text(
            text = "Total: %.2f €".format(total),
            style = MaterialTheme.typography.headlineMedium
        )

        Button(onClick = onBack) {
            Text("Volver al menú")
        }
    }
}

@Composable
fun ToggleButton(texto: String, activo: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (activo) Color.Gray else MaterialTheme.colorScheme.primary
        )
    ) {
        Text(texto)
    }
}

@Composable
fun Ejercicio6(onBack: () -> Unit) {
    val minValue = 100f
    val maxValue = 500f
    val tickInterval = 50
    var sliderValue by remember { mutableStateOf(400f) }
    var snapToTicks by remember { mutableStateOf(false) }

    val ticks = (minValue.toInt()..maxValue.toInt() step tickInterval).toList()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Ejercicio 6", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            // Números a la izquierda del slider (de arriba hacia abajo)
            Column(
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .height(300.dp)
                    .padding(end = 8.dp)
            ) {
                ticks.reversed().forEach {
                    Text(text = it.toString(), fontSize = 12.sp)
                }
            }

            // Slider rotado
            Slider(
                value = sliderValue,
                onValueChange = {
                    sliderValue = if (snapToTicks) {
                        val snapped = (it / tickInterval).roundToInt() * tickInterval
                        snapped.coerceIn(minValue.toInt(), maxValue.toInt()).toFloat()
                    } else it
                },
                valueRange = minValue..maxValue,
                steps = ticks.size - 2,
                modifier = Modifier
                    .height(300.dp)
                    .graphicsLayer(rotationZ = -90f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Spacer(modifier = Modifier.height(16.dp))

        Text("El valor es: ${sliderValue.roundToInt()}", fontSize = 20.sp)

        Spacer(modifier = Modifier.height(32.dp))

        Button(onClick = onBack) {
            Text("Volver al menú")
        }
    }
}

@Composable
fun Ejercicio7(onBack: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    var menuOffset by remember { mutableStateOf(Offset.Zero) }
    var backgroundColor by remember { mutableStateOf(Color.White) }

    Box(

        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    menuOffset = offset
                    expanded = true
                }
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Ejercicio 7", style = MaterialTheme.typography.titleLarge)
            Text("(Toca la pantalla)")
            Button(onClick = onBack) {
                Text("Volver al menú")
            }
        }
        // Contenedor de menú con posición personalizada
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            offset = DpOffset(menuOffset.x.dp, menuOffset.y.dp)
        ) {
            DropdownMenuItem(
                text = { Text("Rojo") },
                onClick = {
                    backgroundColor = Color.Red
                    expanded = false
                }
            )
            DropdownMenuItem(
                text = { Text("Verde") },
                onClick = {
                    backgroundColor = Color.Green
                    expanded = false
                }
            )
            DropdownMenuItem(
                text = { Text("Azul") },
                onClick = {
                    backgroundColor = Color.Blue
                    expanded = false
                }
            )
        }
    }
}

@Composable
fun Ejercicio8(onBack: () -> Unit) {
    var carCount by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Ejercicio 8", style = MaterialTheme.typography.titleLarge)
        Text("Coches en el parking:", style = MaterialTheme.typography.titleLarge)
        Text(
            text = "$carCount",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.primary
        )

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Button(onClick = { carCount++ }) {
                Text("Entró un coche")
            }
            Button(onClick = { if (carCount > 0) carCount-- }) {
                Text("Salió un coche")
            }
        }

        Button(onClick = { carCount = 0 }) {
            Text("Reiniciar")
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(onClick = onBack) {
            Text("Volver al menú")
        }
    }
}

@Composable
fun Ejercicio9(onBack: () -> Unit) {
    var contadorA by remember { mutableStateOf(0) }
    var contadorB by remember { mutableStateOf(0) }
    var contadorC by remember { mutableStateOf(0) }
    var showDialog by remember { mutableStateOf(false) }
    var inputInicial by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Ejercicio 9", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { contadorA++ }) {
                Text("Botón A")
            }
            Button(onClick = { contadorB++ }) {
                Text("Botón B")
            }
            Button(onClick = { contadorC += 2 }) {
                Text("Botón C")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = { showDialog = true }) {
            Text("Ver pulsaciones")
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = inputInicial,
                onValueChange = { inputInicial = it },
                label = { Text("Valor inicial") },
                modifier = Modifier.width(150.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Button(onClick = {
                val valor = inputInicial.toIntOrNull() ?: 0
                contadorA = valor
                contadorB = valor
                contadorC = valor
            }) {
                Text("Iniciar")
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(onClick = onBack) {
            Text("Volver al menú")
        }
    }

    // Diálogo para ver pulsaciones
    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Pulsaciones") },
            text = {
                Column {
                    Text("El botón A se ha pulsado $contadorA veces")
                    Text("El botón B se ha pulsado $contadorB veces")
                    Text("El botón C se ha pulsado $contadorC veces")
                }
            },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cerrar")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    contadorA = 0
                    contadorB = 0
                    contadorC = 0
                    showDialog = false
                }) {
                    Text("Reiniciar")
                    Button(onClick = onBack) {
                        Text("Volver al menú")
                    }
                }
            }
        )
    }
}

@Composable
fun Ejercicio10(onBack: () -> Unit) {
    val grupo1 = listOf("Luis", "Ana", "Carlos")
    val grupo2 = listOf("Sofía", "Pedro", "María")

    var listaNombres by remember { mutableStateOf<List<String>>(emptyList()) }
    var nombreSeleccionado by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Ejercicio 10", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                listaNombres = grupo1
                nombreSeleccionado = ""
            }) {
                Text("Grupo 1")
            }
            Button(onClick = {
                listaNombres = grupo2
                nombreSeleccionado = ""
            }) {
                Text("Grupo 2")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .padding(horizontal = 16.dp)
        ) {
            items(listaNombres) { nombre ->
                Text(
                    text = nombre,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            nombreSeleccionado = nombre
                        }
                        .padding(8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (nombreSeleccionado.isNotEmpty()) "Seleccionado: $nombreSeleccionado" else "",
            style = MaterialTheme.typography.bodyLarge
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = {
            listaNombres = emptyList()
            nombreSeleccionado = ""
        }) {
            Text("Reiniciar")
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = onBack) {
            Text("Volver al menú")
        }
    }
}
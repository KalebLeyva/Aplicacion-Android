plugins {
    id("com.android.application") version "8.10.1" apply false
    id("org.jetbrains.kotlin.android") version "1.9.20" apply false
}
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
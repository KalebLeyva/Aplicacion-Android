pluginManagement {
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "BlockLock2"
include(":app")